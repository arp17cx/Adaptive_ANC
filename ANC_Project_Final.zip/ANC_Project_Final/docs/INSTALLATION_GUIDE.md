# Windows 安装指南

## 📦 第一次使用 - 完整步骤

### 步骤1: 安装GCC编译器

#### 推荐方案: TDM-GCC (最简单)

1. **下载TDM-GCC**
   - 访问: https://jmeubank.github.io/tdm-gcc/
   - 下载最新版 (例如: tdm64-gcc-10.3.0-2.exe)

2. **安装**
   - 运行下载的安装程序
   - 选择 "Create" (新安装)
   - **重要**: 勾选 "Add to PATH" 选项
   - 点击 "Install"
   - 等待安装完成

3. **验证安装**
   - 按 Win+R，输入 `cmd`，回车
   - 在命令行输入: `gcc --version`
   - 如果显示版本号（例如 gcc 10.3.0），说明安装成功
   - 如果提示"不是内部或外部命令"，需要重启电脑

### 步骤2: 解压程序文件

1. 将所有文件解压到一个文件夹，例如:
   ```
   C:\ANC_System\
   ```

2. 确保以下文件都在同一目录:
   ```
   ✓ run.bat
   ✓ build.bat
   ✓ clean.bat
   ✓ main.c
   ✓ config.h
   ✓ coeffs.h
   ✓ wav_io.c 和 wav_io.h
   ✓ fir_filter.c 和 fir_filter.h
   ✓ time_domain_sim.c 和 time_domain_sim.h
   ✓ logger.c 和 logger.h
   ✓ README_WINDOWS.md
   ```

### 步骤3: 运行程序

1. **第一次运行**
   - 双击 `run.bat`
   - 程序会自动:
     - 检测gcc
     - 编译所有源代码
     - 运行程序
   - 等待完成（约10-30秒）

2. **查看输出**
   - `anc_log.txt` - 完整日志
   - `output_comparison.wav` - 音频对比文件

3. **后续运行**
   - 直接双击 `run.bat` 即可
   - 或双击 `anc_system.exe`

## 🎯 快速测试

运行后应该看到类似输出:
```
============================================
  Adaptive ANC System with Time Domain Sim
============================================

Configuration:
  DSP Sample Rate: 32000 Hz
  Realtime Sample Rate: 375000 Hz
  FFT Length: 2048
  Process Interval: 5 ms

WAV file not found: input_4ch.wav
Using generated signal instead
Generated 3750000 samples at 375000 Hz

...

Adaptation Loop Completed
Total iterations: 100

Output files:
  - anc_log.txt (log file)
  - output_comparison.wav (2-channel comparison)
```

## 🔧 可选: 使用真实录音

如果你有真实录音数据:

1. **准备WAV文件**
   - 命名为: `input_4ch.wav`
   - 至少2个通道
   - 通道0 = 参考麦(FF)
   - 通道1 = 误差麦(FB)

2. **准备次级路径 (可选)**
   - 命名为: `secondary_path.bin`
   - 二进制文件, 4096个float32

3. **放置文件**
   - 将文件放在程序目录 (与run.bat同一目录)

4. **运行**
   - 双击 `run.bat`
   - 程序会自动检测并使用这些文件

## 🐛 问题排查

### 问题1: "gcc不是内部或外部命令"

**原因**: gcc未安装或未添加到PATH

**解决方案**:
1. 重新安装TDM-GCC，确保勾选"Add to PATH"
2. 或手动添加到PATH:
   - 右键"此电脑" → 属性 → 高级系统设置
   - 环境变量 → 系统变量 → Path → 编辑
   - 添加gcc安装目录 (例如: `C:\TDM-GCC-64\bin`)
3. 重启电脑

### 问题2: 编译错误 "No such file or directory"

**原因**: 源文件不完整

**解决方案**:
确保所有.c和.h文件都在同一目录

### 问题3: 运行时崩溃

**原因**: 可能是内存不足

**解决方案**:
编辑 `main.c`，减少生成信号的长度:
```c
// 第87行左右
total_samples = sample_rate_actual * 5;  // 改为5秒
```

### 问题4: 输出文件没有生成

**原因**: 程序异常退出

**解决方案**:
1. 查看 `anc_log.txt` (如果存在)
2. 在命令行运行查看错误:
   ```cmd
   cd C:\ANC_System
   anc_system.exe
   ```

## 📝 目录结构示例

正确的目录结构:
```
C:\ANC_System\
├── run.bat                    ← 双击这个运行
├── build.bat
├── clean.bat
├── main.c
├── config.h
├── coeffs.h
├── wav_io.c
├── wav_io.h
├── fir_filter.c
├── fir_filter.h
├── time_domain_sim.c
├── time_domain_sim.h
├── logger.c
├── logger.h
├── README_WINDOWS.md
├── INSTALLATION_GUIDE.md     ← 本文件
│
├── [可选输入]
├── input_4ch.wav             (可选)
├── secondary_path.bin        (可选)
│
└── [运行后生成]
    ├── anc_system.exe
    ├── *.o (中间文件)
    ├── anc_log.txt
    └── output_comparison.wav
```

## ✅ 成功标志

程序运行成功后你应该看到:
1. 命令行窗口显示进度
2. 生成 `anc_log.txt` 文件
3. 生成 `output_comparison.wav` 文件
4. 窗口最后显示 "Execution Completed"

## 🎉 开始使用

现在你可以:
1. 双击 `run.bat` 运行程序
2. 查看 `anc_log.txt` 了解详细过程
3. 使用音频播放器打开 `output_comparison.wav` 对比降噪效果

祝使用愉快！
